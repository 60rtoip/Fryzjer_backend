<?php

require __DIR__ . "/../config.php";
require __DIR__ . "/../services.php";


if (!isset($_SESSION['user_id'])) {
    apiError("UNAUTHORIZED", "User not logged in");
}

$date = $_POST['date'] ?? null;
$hour = $_POST['hour'] ?? null;
$service = $_POST['service'] ?? null;

if (!$date || !$hour || !$service) {
    apiError("INVALID_INPUT", "Missing data");
}

$hour = substr($hour, 0, 5);

/* day off */
$stmt = $pdo->prepare("SELECT 1 FROM days_off WHERE date = ?");
$stmt->execute([$date]);
if ($stmt->fetch()) {
    apiError("DAY_OFF", "Day off");
}

$stmt = $pdo->prepare("
    SELECT gender, verified
    FROM users
    WHERE id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    apiError("USER_NOT_FOUND", "User not found");
}

if (!$user['verified']) {
    apiError("NOT_VERIFIED", "Account not verified");
}

/* service duration */
try {
    $duration = getServiceDuration($user['gender'], $service);
} catch (Exception $e) {
    apiError("INVALID_SERVICE", "Service not allowed");
}

/* working hours */
$start = new DateTime("$date $hour");
$end   = (clone $start)->modify("+{$duration} minutes");
$open  = new DateTime("$date 09:00");
$close = new DateTime("$date 18:00");

if ($start < $open || $end > $close) {
    apiError("OUTSIDE_WORKING_HOURS", "Outside working hours");
}

$stmt = $pdo->prepare("
    SELECT id FROM reservations
    WHERE date = ?
    AND TIME(hour) < ?
    AND ADDTIME(hour, SEC_TO_TIME(duration*60)) > ?
");
$stmt->execute([$date, $end->format("H:i"), $hour]);
if ($stmt->rowCount() > 0) {
    apiError("BUSY", "Slot busy");
}

$stmt = $pdo->prepare("
    INSERT INTO reservations (user_id, date, hour, duration, service_type)
    VALUES (?, ?, ?, ?, ?)
");
$stmt->execute([
    $_SESSION['user_id'],
    $date,
    $hour,
    $duration,
    $service
]);

apiSuccess("Reservation added");