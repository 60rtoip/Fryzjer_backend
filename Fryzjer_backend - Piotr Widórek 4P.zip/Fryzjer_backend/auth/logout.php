<?php
require __DIR__ . "/../config.php";

/* ZABEZPIECZENIE: jeśli sesja nie działa */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* Wyczyść dane sesji */
$_SESSION = [];

/* Zniszcz sesję */
session_destroy();

/* Odpowiedź API */
apiSuccess("Logged out successfully");